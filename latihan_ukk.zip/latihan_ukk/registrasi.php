<?php
   
	include("conn.php");

	if (isset($_POST['submit'])) {
		$user = $_POST['username'];
		$pass = $_POST['password'];

		if ($user == "" || $pass == ""  ) {
			echo "<br/>";

			echo "All fields should be filled. Either one or many fields are empty.";
			echo "<br/>";
			echo "<br/>";
			echo "<br/>";

			echo "<a class= 'btn btn-primary' href='register.php'>Go back</a>";
		} else {
			mysqli_query($koneksi, "INSERT INTO users( username, password) VALUES( '$user','$pass')")
				or die("Could not execute the insert query.");

			header("Location: login.php");
		
			
		}
	}
		?>
 
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
 
    <title>Niagahoster Register</title>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <div class="container mt-4">
        <form action="" method="POST" class="login-email">
            <h2>Silahkan Register Jika Belum Memiliki Akun</h2>
            <div class="input-group">
                <input type="text" placeholder="Username" name="username" class="form-label" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" name="password"   class="form-label" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Confirm Password" name="cpassword"  class="form-label" required>
            </div>
            <div class="input-group">
                <button name="submit" class="btn btn-primary">Register</button>
            </div>
            <p>Anda sudah punya akun? <a href="index.php" class="btn btn-primary">Login </a></p>
        </form>
    </div>
</body>
</html>